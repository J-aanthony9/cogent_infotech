import java.util.Scanner;

public class ProductDAO {
    Scanner scan = new Scanner(System.in);
    public void create(Product[] pArr, int i){
        Product p = new Product();
        pArr[i] = p;
        System.out.println("Please enter the product ID:");
        pArr[i].setProductID(scan.nextInt());
        System.out.println("Please enter the product name:");
        pArr[i].setProductName(scan.next());
        System.out.println("Please enter the product price:");
        pArr[i].setProductPrice(scan.nextInt());
    }

    public void read(Product[] pArr){
        for(Product p:pArr){
            if(p == null) {
                continue;
            }
            System.out.println("Product ID is:[" + p.getProductID() + "]");
            System.out.println("Product name is:\"" + p.getProductName() + "\"");
            System.out.println("Product price is:$" + p.getProductPrice());
            System.out.print("\n");

        }
    }

    public void update(Product[] pArr, int id){
        Scanner scan = new Scanner(System.in);
        for(int i = 0; i < pArr.length; i++){
            if(pArr[i].getProductID() == id){
                Product p = new Product();
                pArr[i] = p;
                System.out.println("Please enter the product ID:");
                pArr[i].setProductID(scan.nextInt());
                System.out.println("Please enter the product name:");
                pArr[i].setProductName(scan.next());
                System.out.println("Please enter the product price:");
                pArr[i].setProductPrice(scan.nextInt());
                break;
            }
        }



    }

    public void delete(Product[] pArr, int id){
        for(int i = 0; i < pArr.length; i++) {
            if (pArr[i].getProductID() == id) {
                pArr[i] = null;
                break;
            }
        }
        System.out.println("*Product Deleted*");
        System.out.print("\n");
    }
}



