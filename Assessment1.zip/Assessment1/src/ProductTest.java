import java.util.Scanner;

public class ProductTest {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        ProductDAO dao= new ProductDAO();
        Product[] pArr = null;
        int choice;

        do {
            System.out.println("********************Main Menu********************");
            System.out.println("1->Add product");
            System.out.println("2->Print product details");
            System.out.println("3->update a product");
            System.out.println("4->Delete a product");
            System.out.println("5->Exit");
            System.out.println("Please enter the function you want to complete: ");
            choice = scan.nextInt();

            switch(choice){

                case 1:
                    System.out.println("How many products you want to add?");
                    int count = scan.nextInt();
                    pArr = new Product[count];
                    for(int i = 0; i < pArr.length; i++){
                        dao.create(pArr,i);
                    }
                    break;
                case 2:

                    if (pArr.length == 0){
                        System.out.println("Sorry, there are no products in this directory");
                    }
                    else{
                        dao.read(pArr);
                    }
                    break;
                case 3:
                    System.out.println("Please enter the ID of the product you want to update:");
                    int pNumUpdate = scan.nextInt();
                    dao.update(pArr, pNumUpdate);
                    dao.read(pArr);
                    break;
                case 4:
                    System.out.println("Please enter the ID of the product you want to delete:");
                    int pNum = scan.nextInt();

                    dao.delete(pArr, pNum);
                    dao.read(pArr);

                    break;
                case 5:
                    System.out.println("Exiting system now!!!");
                    System.exit(0);
                    break;
            }

        }while(choice!=5);

    }
}




