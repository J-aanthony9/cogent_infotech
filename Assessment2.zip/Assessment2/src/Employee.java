public class Employee {

    public int empNo;
    public String empName;
    public String empAddress;
    public String empEmail;
    public int empSalary;

    public Employee(int empNo, String empName, String empAddress, String empEmail, int empSalary){
        this.empNo = empNo;
        this.empName = empName;
        this.empAddress = empAddress;
        this.empEmail = empEmail;
        this.empSalary = empSalary;
    }

    public Employee(){}

    public int getEmpNo() {
        return empNo;
    }

    public String getEmpName() {
        return empName;
    }

    public String getEmpAddress() {
        return empAddress;
    }

    public String getEmpEmail() {
        return empEmail;
    }

    public int getEmpSalary() {
        return empSalary;
    }

    public void setEmpNo(int empNo) {
        this.empNo = empNo;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public void setEmpAddress(String empAddress) {
        this.empAddress = empAddress;
    }

    public void setEmpEmail(String empEmail) {
        this.empEmail = empEmail;
    }

    public void setEmpSalary(int empSalary) {
        this.empSalary = empSalary;
    }

}
