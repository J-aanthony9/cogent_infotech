import java.util.ArrayList;

public interface EmployeeDAO {

    void addEmployee(ArrayList<Employee> arr);





    void updateEmployee(ArrayList<Employee> arr, int ID);

    void deleteEmployee(ArrayList<Employee> arr, int ID);

    void readAll(ArrayList<Employee> arr);


    void searchEmp(ArrayList<Employee> arr, int ID);

    public void sortEmpNames(ArrayList<Employee> arr);

}
