import java.util.ArrayList;
import java.util.Scanner;

public class EmployeeDAOIMPL implements EmployeeDAO{

    public EmployeeDAOIMPL(){}

    @Override
    public void addEmployee(ArrayList<Employee> arr) {
        Scanner sc = new Scanner(System.in);
        int choice;


        System.out.println("How many employees would you like to add?");
        choice = sc.nextInt();

        for(int i=0; i < choice; i++){
            Employee t = new Employee();
            System.out.println("What is the employees ID?");
            t.setEmpNo(sc.nextInt());
            System.out.println("What is the employees name?");
            t.setEmpName(sc.next());
            System.out.println("What is the employees address?");
            t.setEmpAddress(sc.next());
            System.out.println("What is the employees email?");
            t.setEmpEmail(sc.next());
            System.out.println("What is the employees salary?");
            t.setEmpSalary(sc.nextInt());

            arr.add(t);
        }
        System.out.println("");
        System.out.println("*fireworks* EMPLOYEES ADDED!!! *fireworks*");


    }

    @Override
    public void updateEmployee(ArrayList<Employee> arr, int ID) {
        Scanner sc = new Scanner(System.in);
        Employee t = null;

        for(Employee e : arr) {
            if(e.getEmpNo() == ID) {
                t = e;
                break;
            }
        }

        if(t != null) {
            System.out.println("What is the employees new ID?");
            t.setEmpNo(sc.nextInt());
            System.out.println("What is the employees name?");
            t.setEmpName(sc.next());
            System.out.println("What is the employees address?");
            t.setEmpAddress(sc.next());
            System.out.println("What is the employees email?");
            t.setEmpEmail(sc.next());
            System.out.println("What is the employees salary?");
            t.setEmpSalary(sc.nextInt());

            System.out.println("");
            System.out.println("EMPLOYEE UPDATED");
        } else {
            System.out.println("Employee with ID " + ID + " not found.");
        }
    }

    @Override
    public void deleteEmployee(ArrayList<Employee> arr, int ID) {
        Employee t = null;

        for(Employee e : arr) {
            if(e.getEmpNo() == ID) {
                t = e;
                break;
            }
        }

        if(t != null) {
            arr.remove(t);
            System.out.println("");
            System.out.println("EMPLOYEE DELETED");
        } else {
            System.out.println("Employee with ID " + ID + " not found.");
        }
    }


    @Override
    public void readAll(ArrayList<Employee> arr) {

        for(Employee t : arr){
            System.out.println("ID Number:[" + t.getEmpNo() + "] Name: " + t.getEmpName());
        }
    }



    public void searchEmp(ArrayList<Employee> arr, int id) {
        for (Employee e : arr) {
            if (e.getEmpNo() == id) {
                System.out.println("ID Number:[" + e.getEmpNo() + "] Name: " + e.getEmpName() + " exists in our system.");
                break;
            }
        }



    }

    @Override
    public void sortEmpNames(ArrayList<Employee> arr) {
        arr.sort(new EmployeeNameComparator());
    }




}
