import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<Employee> arr = new ArrayList<>();
        EmployeeDAOIMPL dao = new EmployeeDAOIMPL();
        Scanner sc = new Scanner(System.in);

        int choice;
        do {
            System.out.println("*****Menu*****");
            System.out.println("Please choose an option:");
            System.out.println("Add Employee-> 1");
            System.out.println("Update Employee->2");
            System.out.println("Delete Employee->3");
            System.out.println("Print Employees->4");
            System.out.println("Search Employees->5");
            System.out.println("Sort Employees->6");
            System.out.println("Exit->7");
            choice = sc.nextInt();

            switch(choice){
                case 1:


                    dao.addEmployee(arr);
                    break;
                case 2:
                    System.out.println("What is the employees ID?:");
                    int ID = sc.nextInt();
                    dao.updateEmployee(arr,ID);
                    break;
                case 3:
                    System.out.println("What is the employees ID?:");
                    ID = sc.nextInt();
                    dao.deleteEmployee(arr,ID);
                    break;
                case 4:
                    System.out.println("On it...");
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    System.out.println("Here we are:");
                    dao.readAll(arr);
                    break;
                case 5:
                    System.out.println("What is the employees ID?:");
                    ID = sc.nextInt();
                    dao.searchEmp(arr, ID);
                    break;
                case 6:
                    dao.sortEmpNames(arr);
                    break;
                case 7:
                    System.out.println("Logging out now ...");
                    try {
                        Thread.sleep(1000);
                        System.out.print(".");
                        Thread.sleep(1000);
                        System.out.print(".");
                        Thread.sleep(1000);
                        System.out.print(".");
                        Thread.sleep(1000);

                        System.out.println("COMPLETE");
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    break;


            }



        }while(choice != 7);
    }
}
