public class ACMEBicycle implements Bicycle{
    int cadence=0;
    int speed=0;
    int gear=1;
    @Override
    public void changeCadence(int newValue){
        this.cadence=newValue;
    }
    public void changeGear(int newValue){
        this.gear=newValue;
    }
    public void speedUp(int increment){
        speed=speed + increment;
    }
    public void applyBrakes(int decrement){
        speed=speed - decrement;
    }
    public void printStates(){
        System.out.println("Cadence: " + this.cadence + "\nGear:" + this.gear + "\nSpeed:" + this.speed);
    }
}
