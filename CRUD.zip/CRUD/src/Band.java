import java.util.Random;

public class Band {
    public static void main(String[] args){
        Instrument[] arr = new Instrument[10];

        Random r = new Random();

        Piano p = new Piano();
        Flute f = new Flute();
        Guitar g = new Guitar();

        for(int i=0; i<arr.length;i++){
            int x = r.nextInt(3) + 1;

            if (x == 1){
                arr[i] = p;
            }else if(x == 2){
                arr[i] = f;
            }
            else{
                arr[i] = g;
            }
        }

        int count = 0;

        for(Instrument inst:arr){
            inst.play();

            if (inst instanceof Piano){
                System.out.println("and it is in index:" + count);
            }
            else if (inst instanceof Flute){
                System.out.println("and it is in index:" + count);
            }
            else if (inst instanceof Guitar){
                System.out.println("and it is in index:" + count);
            }
            count++;

        }

    }
}
