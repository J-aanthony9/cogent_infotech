
import java.util.Scanner;
public class BookDAO {

    Scanner scan = new Scanner(System.in);
    public void create(Book[] book, int i){
        Book b = new Book();
        book[i] = b;
        System.out.println("Please enter the book ID:");
        book[i].setBookID(scan.nextInt());
        System.out.println("Please enter the book name:");
        book[i].setBookName(scan.next());
        System.out.println("Please enter the book price:");
        book[i].setPrice(scan.nextInt());
    }

    public void read(Book[] book){
        for(Book b:book){
            if(b == null) {
                continue;
            }
            System.out.println("Book ID is:" + b.getBookID());
            System.out.println("Book name is:" + b.getBookName());
            System.out.println("Book price is:" + b.getPrice());
            System.out.print("\n");

        }
    }

    public void update(Book[] book, int id){
        Scanner scan = new Scanner(System.in);
        for(int i = 0; i < book.length; i++){
            if(book[i].getBookID() == id){
                Book b = new Book();
                book[i] = b;
                System.out.println("Please enter the book ID:");
                book[i].setBookID(scan.nextInt());
                System.out.println("Please enter the book name:");
                book[i].setBookName(scan.next());
                System.out.println("Please enter the book price:");
                book[i].setPrice(scan.nextInt());
                break;
            }
        }



    }

    public void delete(Book[] book, int id){
        for(int i = 0; i < book.length; i++) {
            if (book[i].getBookID() == id) {
                book[i] = null;
                break;
            }
        }
        System.out.println("**KAPOOF** Book has been magically deleted!");
        System.out.print("\n");
    }
}

