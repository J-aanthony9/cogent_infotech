import java.util.Scanner;

public class BookShelf {
    public static void main(String[] args){

        Scanner scan = new Scanner(System.in);
        Book[] book = null;
        BookDAO dao= new BookDAO();

        int choice = 0;

        do {
            System.out.println("************************Welcome to the book shelf!!!************************");
            System.out.println("************************Menu************************");
            System.out.println("1->Add book");
            System.out.println("2->Print book details");
            System.out.println("3->update a book");
            System.out.println("4->Remove a book");
            System.out.println("5->Exit");
            System.out.println("Please Enter Your Choice: ");
            choice = scan.nextInt();

            switch(choice){

                case 1:
                    System.out.println("How many records you want to add?");
                    int count = scan.nextInt();
                    book = new Book[count];
                    for(int i = 0; i < book.length;i++){
                        dao.create(book,i);
                    }
                    break;
                case 2:

                    if (book.length == 0){
                        System.out.println("Sorry, there are no books on this shelf");
                    }
                    else{
                            dao.read(book);
                        }
                    break;
                case 3:
                    System.out.println("Please enter the ID of the book you want to update:");
                    int bNumUpdate = scan.nextInt();
                    dao.update(book, bNumUpdate);
                    dao.read(book);
                    break;
                case 4:
                    System.out.println("Please enter the ID of the book you want to delete:");
                    int bNum = scan.nextInt();

                    dao.delete(book, bNum);
                        dao.read(book);

                    break;
                case 5:
                    System.out.println("You are logged out, Have a nice day!");
                    System.exit(0);
                    break;
            }

        }while(choice!=5);

    }
}


