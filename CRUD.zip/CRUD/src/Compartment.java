public abstract class Compartment {
    abstract void notice();
}

class FirstClass extends Compartment{
    @Override
    void notice(){
        System.out.println("First Class");
    }
}

class Ladies extends Compartment{
    @Override
    void notice(){
        System.out.println("Ladies");
    }
}
class General extends Compartment{
    @Override
    void notice(){
        System.out.println("General");
    }
}
class Luggage extends Compartment{
    @Override
    void notice(){
        System.out.println("Luggage");
    }
}
