import java.util.Scanner;

public class Main {
    public static void main(String[] args){

        Scanner scan = new Scanner(System.in);
        Person[] person = null;
        PersonDAO dao= new PersonDAO();

        int choice = 0;

        do {
           System.out.println("************************Menu************************");
            System.out.println("1->Add person");
            System.out.println("1->Print person");
            System.out.println("1->Exit");
            System.out.println("Please Enter Your Choice: ");
            choice = scan.nextInt();

            switch(choice){

                case 1:
                    System.out.println("How many records you want to add?");
                    int count = scan.nextInt();
                    person = new Person[count];
                    for(int i = 0; i < person.length;i++){
                        dao.create(person,i);
                    }
                    break;
                case 2:


            }

        }while(choice!=3);

    }
}
