import java.util.Scanner;

public class PersonDAO {

    Scanner scan = new Scanner(System.in);
    public void create(Person[] person, int i){
        Person p = new Person();
        person[i] = p;
        System.out.println("Please enter the person ID:");
        person[i].setPersonID(scan.nextInt());
        System.out.println("Please enter the person name:");
        person[i].setPersonName(scan.next());
        System.out.println("Please enter the person address:");
        person[i].setPersonAddress(scan.next());
    }

    public void read(Person[] person){
        for(Person p:person){
            System.out.println("Person ID is:" + p.getPersonID());
            System.out.println("Person name is:" + p.getPersonName());
            System.out.println("Person Address is:" + p.getPersonAddress());

        }
    }

    public void update(){

    }

    public void delete(){

    }
}
