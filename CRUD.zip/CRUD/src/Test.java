public class Test {

    public static void main(String[] args){
        ACMEBicycle bike = new ACMEBicycle();
        bike.changeCadence(10);
        bike.applyBrakes(1);
        bike.changeCadence(2);
        bike.speedUp(5);
        bike.printStates();
    }
}
