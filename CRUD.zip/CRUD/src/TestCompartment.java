import java.util.Random;

public class TestCompartment {
    public static void main(String[] args){
        Compartment[] ar = new Compartment[10];

        Random r = new Random();


        for(int i=0; i<ar.length;i++){
            int x = r.nextInt(4) + 1;

            if(x == 1){
                ar[i] = new FirstClass();
            }
            else if (x==2) {
                ar[i] = new Ladies();
            }
            else if (x==3) {
                ar[i] = new General();
            }
            else if (x==4) {
                ar[i] = new Luggage();
            }
            ar[i].notice();
        }
    }
}
