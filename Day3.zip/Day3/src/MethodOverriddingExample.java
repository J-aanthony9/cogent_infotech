//Overriding example
class Athlete{
    public void behavior(){
        System.out.println("Athlete is playing a sport");
    }
}
class FootballPlayer extends Athlete{
    public void behavior(){
        System.out.println("Football player is playing football");
    }
}

class BasketballPlayer extends Athlete{
    public void behavior(){
        System.out.println("Basketball player is playing basketball");
    }
}



public class MethodOverriddingExample {
    public static void main(String[] args){
        Athlete a = new Athlete();
        Athlete b = new FootballPlayer();
        Athlete c = new BasketballPlayer();

        a.behavior();
        b.behavior();
        c.behavior();
    }
}
