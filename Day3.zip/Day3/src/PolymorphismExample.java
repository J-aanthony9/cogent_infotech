import java.util.Random;

class Car{
    public String speed;
    public String noOfGear;
    public void drive(){
         speed = "120 Mph";
         noOfGear = "6";
    }
    public void display(){
        System.out.println("Speed: " + speed + "\n" + "Number of gears:" + noOfGear);
    }
}
class SportCar extends Car{
    private String aBalloon;
    @Override
    public void drive() {
        super.drive();
        aBalloon = "Gtx 790 flex system";
    }

    public void display(){
        System.out.println("Speed: " + super.speed + "\n" + "Number of gears:" + super.noOfGear
                + "\n" + "Air Balloon Type:" + aBalloon);
    }
}

public class PolymorphismExample {
    public static void main(String[] args){
        Random random = new Random();
        String[] cars = {"Mustang", "Charger", "Lamborgini"};

        Car a = new Car();
        Car b = new SportCar();
        a.drive();
        b.drive();

        a.display();
        System.out.println();
        b.display();
    }
}
