import java.util.Random;

class Medicine{
    public void displayLabel(){
        System.out.println("Fake Med Co." + "\n" + "1000 Medical Ave, Dallas, Tx");
    }
}
class Tablet extends Medicine{
    public void displayLabel(){
        System.out.println("Tablet");
        super.displayLabel();
        System.out.println("Store in a cool dry place.");
    }

}

class Syrup extends Medicine{
    public void displayLabel(){
        System.out.println("Syrup");
        super.displayLabel();
        System.out.println("Do not mix with sprite");
    }
}

class Ointment extends Medicine{
    public void displayLabel(){
        System.out.println("Ointment");
        super.displayLabel();
        System.out.println("Not safe for human consumption");
    }
}


public class TestMedicine{
    public static void main(String[] args){
        Medicine[] medCabinet = new Medicine[10];
        Medicine med;
        Random r = new Random();

        for (int i=0; i< medCabinet.length;i++){
            int x = r.nextInt(3) + 1;

            if(x == 1){
                med = new Tablet();
            }else if(x == 2){
                med = new Syrup();
            }
            else{
                med = new Ointment();
            }

            med.displayLabel();
            System.out.println("");
            medCabinet[i] = med;



        }

    }
}
