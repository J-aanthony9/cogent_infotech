import java.sql.SQLOutput;

public class Rectangle {
    double length = 0;
    double breadth = 0;

    public Rectangle(double len, double bre){
        this.length = len;
        this.breadth = bre;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public void setBreadth(double breadth) {
        this.breadth = breadth;
    }

    public double getLength() {
        return length;
    }

    public double getBreadth() {
        return breadth;
    }

    public void calcArea(){
        System.out.println(length * breadth);
    }

    public void display(){
        calcArea();
    }
}
