import java.util.Scanner;

public class TestRectangle {
    public static void main(String[] args) {
        Rectangle[] arr = new Rectangle[5];
        Scanner scan = new Scanner(System.in);
        double len;
        double brd;

        for (int i=0;i<5;i++){
            System.out.println("Enter length");
            len = scan.nextDouble();
            System.out.println("Enter Breadth");
            brd = scan.nextDouble();

            Rectangle r = new Rectangle(len, brd);
            arr[i] = r;
        }

        for(Rectangle i:arr){
            i.display();
        }
    }
}
