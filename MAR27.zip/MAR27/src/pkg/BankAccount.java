package pkg;

public class BankAccount {
    int accNo;
    String custName;
    String accType;
    float balance;

    public BankAccount(int accNo, String custName, String accType, float balance){
        this.accNo = accNo;
        this.custName = custName;
        this.accType = accType;
        this.balance = balance;
    }

    public void deposit(float amt) throws NegativeAmountException{
        if(amt > 0) {
            balance += amt;
        }else{
            throw new NegativeAmountException("Negative amount");
        }
    }
    public void withdrawl(float amt)throws LowBalanceException{

        if(accType == "Savings" && balance > 1000 && balance > amt){
            balance -= amt;
        }
        else if(accType == "Current" && balance > 5000 && balance > amt){
            balance -= amt;
        }
        else{
            throw new LowBalanceException("Balance too low to withdrawl");
        }

    }
    public float getBalance() throws LowBalanceException{

        if(accType == "Savings" && balance > 1000){
            return balance;
        }
        else if(accType == "Current" && balance > 5000){
            return balance;
        }
        else{
            throw new LowBalanceException("Balance too low to withdrawl");
        }
    }
    public void displayMenu(){
        System.out.println("***********Menu***********");
        System.out.println("Select an operation:");
        System.out.println("1->deposit");
        System.out.println("2->withdrawl");
        System.out.println("3->get balance");
        System.out.println("4->Exit");
        System.out.println("Please enter your selection:");
    }

}
