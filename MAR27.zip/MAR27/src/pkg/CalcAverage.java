package pkg;

public class CalcAverage {
    int avg;
    int sum;

    public double avgFirstN(int N) {

        try{
            if (N > 0){
                for(int i = 0; i < N; i++){
                    sum += i;
                }

                avg = sum / N;
            }


        }catch(IllegalArgumentException e){
            System.out.println("Natural Numbers Only!");
        }
        return avg;
    }
}
