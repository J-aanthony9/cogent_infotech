package pkg;

import javax.lang.model.type.PrimitiveType;
import java.util.PrimitiveIterator;

public class Convert {
    public static void main(String[] args) {
        byte b = 5;
        short s = 6;
        int i = 7;
        long l = 800000l;
        float f = 90.26f;
        double d = 56.22d;
        boolean q = false;
        char c = 'c';

        Byte bb = Byte.valueOf(b);
        Short ss = Short.valueOf(s);
        Integer ii = Integer.valueOf(i);
        Long ll = Long.valueOf(l);
        Float ff = Float.valueOf(f);
        Double dd = Double.valueOf(d);
        Boolean qq = Boolean.valueOf(q);
        Character cc = Character.valueOf(c);

        byte bbb = bb.byteValue();
        short sss = ss.shortValue();
        int iii = ii.intValue();
        long lll = ll.longValue();
        float fff = ff.floatValue();
        double ddd = dd.doubleValue();
        boolean qqq = qq.booleanValue();
        char ccc = cc.charValue();

    }
}
