package pkg;

public class Emp {
    int emplId;
    String empName;
    String designation;
    double basic;
    double HRA;

    public final double MANAGER_HRA = 0.1d;
    public final double OFFICER_HRA = 0.12d;
    public final double CLERK_HRA = 0.05d;

    public Emp(int emplId, String empName, String designation, double basic) throws LowSalException {

        if (basic >= 500){
            this.emplId = emplId;
            this.empName = empName;
            this.designation = designation;
            this.basic = basic;
        }else{
            throw new LowSalException("\nBasic below 500 is invalid");

        }

    }
    public void printDET(){
        System.out.println("Employee ID:" + emplId);
        System.out.println("Employee Name:" + empName);
        System.out.println("Designation:" + designation);
        System.out.println("Basic:$" + basic);
        System.out.println("HRA:" + HRA);
        System.out.println();
    }

    public void calculateHRA(){

        switch(designation){
            case "Officer":
                HRA = basic * OFFICER_HRA;
                break;
            case "Manager":
                HRA = basic * MANAGER_HRA;
                break;
            case "Clerk":
                HRA = basic * CLERK_HRA;
                break;
        }
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }
}
