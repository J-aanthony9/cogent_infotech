package pkg;

import java.sql.SQLOutput;
import java.util.Scanner;

public class ErrorDemo {
    public static void main(String[] args) {
       Scanner scan = new Scanner(System.in);
        System.out.println("Please enter two numbers:");
        int x = scan.nextInt();
        int y = scan.nextInt();

        try{
            int z=x/y;
            System.out.println(z);
        }catch(ArithmeticException e){
            System.out.println("Division by zero is not allowed!!!");
        }
        System.out.println("Welcome!!!");
    }
}
