package pkg;

import java.util.Scanner;

public class ExceptionDemo {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter two numbers:");
        int x = scan.nextInt();
        int y = scan.nextInt();
        int z = x/y;
        System.out.println(z);
        System.out.println("Welcome!!!");
    }
}
