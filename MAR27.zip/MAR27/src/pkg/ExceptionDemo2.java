package pkg;

public class ExceptionDemo2 {
    public static void main(String[] args){
        String[] names = {"Shiva","John","Anthony","Sophia"};

        System.out.println(names[10]);
        System.out.println("after exception");
    }
}
