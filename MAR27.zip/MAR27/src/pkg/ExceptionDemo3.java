package pkg;

class Arithmetic {
    public void division(int x, int y) throws ArithmeticException {
        int z=x/y;
        System.out.println(z);
    }

}
public class ExceptionDemo3 {
    public static void main(String[] args) {

        try{
            String input = args[0];
            System.out.println("Input is:" + input);
            int output = Integer.parseInt(input);
            System.out.println("Output is:" + output);
        }catch(Exception e){
            e.printStackTrace();
        }finally {
            System.out.println("This is going to execute either way bruh");
        }
        System.out.println("After exception");
    }
}
