package pkg;

import java.sql.SQLOutput;

public class GCDemo {
    int objID;
    GCDemo(int objID){
        this.objID = objID;

        System.out.println("Created:"+this.objID);
    }

    public static void main(String[] args) {
        GCDemo[] arr = new GCDemo[1000];
        for (int i = 1; i < 1000; i++){
            new GCDemo(i);
            System.gc();
        }

    }

    @Override
    protected void finalize() throws Throwable{
        System.out.println("Finalized:" + this.objID);
    }

}
