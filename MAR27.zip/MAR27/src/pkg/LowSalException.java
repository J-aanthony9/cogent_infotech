package pkg;

public class LowSalException extends Exception{
    public LowSalException(String s){
        super(s);
    }
}
