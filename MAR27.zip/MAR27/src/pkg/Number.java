package pkg;


public class Number {
    int firstNum;
    int secNum;
    double result;

    public Number(int a, int b){
        this.firstNum = a;
        this.secNum = b;
    }

    public void displayMenu(){
        System.out.println("***********Menu***********");
        System.out.println("Select an operation:");
        System.out.println("1->Add");
        System.out.println("2->Subtract");
        System.out.println("3->Multiply");
        System.out.println("4->Divide");
        System.out.println("5->Exit");
        System.out.println("Please enter your selection");
    }

    public void add(){
        result = (double) (firstNum + secNum);
        System.out.println(result);
    }
    public void sub(){
        result = (double) (firstNum - secNum);
        System.out.println(result);
    }
    public void mul(){
        result = (double) (firstNum * secNum);
        System.out.println(result);
    }
    public void div() throws Exception {
        if(firstNum > 0 && secNum > 0){
            result = (double) (firstNum / secNum);
            System.out.println(result);
        }else{
            System.out.println("Numbers must be greater than zero");
        }

    }
}
