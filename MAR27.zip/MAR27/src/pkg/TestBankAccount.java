package pkg;

import java.util.Scanner;

public class TestBankAccount {
    public static void main(String[] args) throws NegativeAmountException, LowBalanceException {
        BankAccount b = new BankAccount(111, "Jay", "Savings", 1000f);
        int choice = 0;
        float num;
        Scanner scan = new Scanner(System.in);


        try {
            do {
                b.displayMenu();
                choice = scan.nextInt();

                switch (choice) {
                    case 1:
                        System.out.println("How much would you like to deposit?");
                        num = scan.nextFloat();
                        b.deposit(num);
                        break;
                    case 2:
                        System.out.println("How much would you like to withdrawl?");
                        num = scan.nextFloat();
                        b.withdrawl(num);
                        break;
                    case 3:
                        System.out.println(b.getBalance());
                        break;
                }

            } while (choice != 4);

        }catch(NegativeAmountException nm){
            System.out.println(nm.getMessage());
        }catch(LowBalanceException lb){
            System.out.println(lb.getMessage());
        }
    }
}

