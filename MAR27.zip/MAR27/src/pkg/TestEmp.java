package pkg;

public class TestEmp{
    public static void main(String[] args)throws LowSalException {

        try {
            Emp emp1 = new Emp(111, "Jay","Manager", 650);
            Emp emp2 = new Emp(222, "Kay","Officer", 600);
            Emp emp3 = new Emp(333, "Eddy","Clerk", 500);

            emp1.calculateHRA();
            emp2.calculateHRA();
            emp3.calculateHRA();

            emp1.printDET();
            emp2.printDET();
            emp3.printDET();
        }catch(LowSalException e){
            throw new LowSalException(e.getMessage());

        }
    }
}
