package pkg;

public class WrapperDemo {
    public static void main(String[] args) {
        int x = 100;
        Integer y = Integer.valueOf(x); // Boxing (converting primitive to object)

        int z =y.intValue(); //Un-Boxing (converting object to primitive)

        byte t = 100;

        String s = Byte.toString(t);

        byte r = Byte.parseByte(s);


        long w = 1000;
        Long wt =Long.valueOf(w);
        String wer = wt.toString();
        Long rr = Long.valueOf(wer);//parseLong will return a primitive while valueOf returns object
    }
}
