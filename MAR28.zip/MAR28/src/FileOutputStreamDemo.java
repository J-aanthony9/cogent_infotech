import java.io.*;

public class FileOutputStreamDemo {

    public static void main(String[] args) {
        FileInputStream fis = null;
        FileOutputStream fos = null;

        try{
            fis = new FileInputStream("/Users/j.a.person/Downloads/employee.txt");
            fos = new FileOutputStream("/Users/j.a.person/Downloads/newEmployee.txt");

            int data;

            while((data = fis.read()) != -1){
                fos.write(data);
            }
            System.out.println("File copied successfully");
        }catch(Exception e){
            e.printStackTrace();
        }finally {
            try {
                fis.close();
                fos.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
