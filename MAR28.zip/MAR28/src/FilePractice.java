import java.io.*;
import java.util.Scanner;

public class FilePractice {
    public static void main(String[] args) {
        FileReader fr = null;
        FileWriter fw = null;
        Scanner scan = new Scanner(System.in);

        try {
            fr = new FileReader("/Users/j.a.person/Downloads/" + args[0]);
            fw = new FileWriter("/Users/j.a.person/Downloads/" + args[1]);
            int ch;

            System.out.println("Would you like to overwrite this file? 1->Yes, 2->No");
            int choice = scan.nextInt();
            if(choice == 1){
            while((ch=fr.read())!=-1){
                fw.write(ch);
            }
            System.out.println("Operation Complete!");}
            else{
                System.out.println("cool bye");
            }
            fr.close();
            fw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
