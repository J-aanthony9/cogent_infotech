import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReaderAndWriterDemo {
    public static void main(String[] args) {
        FileReader fr = null;
        FileWriter fw = null;


        try {
            fr = new FileReader("/Users/j.a.person/Downloads/hi.txt");
            fw = new FileWriter("/Users/j.a.person/Downloads/msg.txt");
            int ch;
            while((ch=fr.read())!=-1){
                fw.write(ch);
            }
            System.out.println("File Copied!");
            fr.close();
            fw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
