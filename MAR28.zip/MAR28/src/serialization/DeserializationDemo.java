package serialization;

import java.io.*;

public class DeserializationDemo {

    public static void main(String[] args) {

        try {
            FileInputStream fis = new FileInputStream("/Users/j.a.person/Documents/streams/Peeps.ser");
            ObjectInputStream ois = new ObjectInputStream(fis);
            Object obj = ois.readObject();
            Person p = (Person) obj;

            System.out.println("Roll number:" + p.rollNum);
            System.out.println("Name:" + p.name);
            System.out.println("Age:" + p.age);
            System.out.println("Address:" + p.address);

            fis.close();
            ois.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);

        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}