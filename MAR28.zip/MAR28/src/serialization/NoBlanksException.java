package serialization;

public class NoBlanksException extends Exception{
    public NoBlanksException(String s){
        super(s);
    }
}
