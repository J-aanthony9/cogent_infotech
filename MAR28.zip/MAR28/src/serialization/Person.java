package serialization;

import java.io.Serializable;

public class Person implements Serializable {

    int rollNum;
    String name;
    int age;
    String address;

    public Person(int rollNum, String name, int age, String address) throws NoBlanksException, NumberFormatException {

            this.rollNum = rollNum;
            this.name = name;
            this.age = age;
            this.address = address;

    }
}
