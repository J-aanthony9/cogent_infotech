package serialization;

import java.io.*;
import java.util.Scanner;

public class SerializedChallenge {
    public static void main(String[] args) {
        FileOutputStream fos;
        ObjectOutputStream oos;
        Scanner scan = new Scanner(System.in);

        try {
            fos = new FileOutputStream("/Users/j.a.person/Documents/streams/jeeps.ser", true);
            oos = new ObjectOutputStream(fos);

            System.out.println("Hi there! We will be creating person objects now :)");
            System.out.println("Please enter the roll Num:");
            String rollNum = scan.next();
            System.out.println("Please enter the name:");
            String name = scan.next();
            System.out.println("Please enter the age:");
            String age = scan.next();
            System.out.println("Please enter the address:");
            String address = scan.next();




            Person person = new Person(Integer.parseInt(rollNum), name, Integer.parseInt(age), address);
            oos.writeObject(person);
            System.out.println("Object Serialized!");
            fos.close();
            oos.close();
        } catch (FileNotFoundException ex) {
            throw new RuntimeException(ex);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        } catch (NoBlanksException ex) {
            throw new RuntimeException(ex);
        }

    }
}
