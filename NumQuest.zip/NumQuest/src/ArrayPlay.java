public class ArrayPlay {
    public static void main(String[] args){

        int[] A = {3,2,4,5,6,4,5,6,3,2,3,4,7,1,2,0,0,0};
        int sum = 0;
        int avg = 0;
        int min = A[0];

        for(int i=0; i<15;i++){
            sum += A[i];
            if(A[i] < min){
                min = A[i];
            }
        }
        avg = sum / 15;

        A[15] = sum;
        A[16] = avg;
        A[17] = min;

        System.out.println("Here is your new array: ");
        System.out.print("{");
        for(int num:A){
            System.out.print("[" + num + "]");
        }
        System.out.print("}");
        System.out.println();
        System.out.println("\nA[15] SUM: " + sum + "\n" + "A[16] AVERAGE: " + avg + "\n"
            + "A[17] MIN VALUE: " + min);

    }
}
