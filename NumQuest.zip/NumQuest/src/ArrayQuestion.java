public class ArrayQuestion {
    public static void main(String[] args) {
        int num1 = Integer.valueOf(args[0]);
        int num2 = Integer.valueOf(args[1]);
        int[] numArray = new int[25];

        int max = 40;
        int min = 1;
        int range = max - min + 1;

        boolean num1Found = false;
        boolean num2Found = false;

        System.out.println("Your first number was: " + num1);
        System.out.println("Your second number was: " + num2);

        for (int i = 0; i < numArray.length; i++) {
            numArray[i] = (int) (Math.random() * range) + min;
            if (numArray[i] == num1) {
                num1Found = true;
            } else if (numArray[i] == num2) {
                num2Found = true;
            }
        }
        int count = 0;
        num1Found = true;
        num2Found = true;

        if(num1Found && num2Found){
            System.out.println("Its Bingo!");
        }
        else{
            System.out.println("Sorry no bingo :( ");
            System.out.println("Here were the numbers: ");
            for(int num:numArray){
                System.out.print("[" + num + "] ");
                count++;
                if (count % 5 == 0)
                    System.out.println();
            }
        }
    }
}
