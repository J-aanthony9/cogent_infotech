import java.util.Scanner;

public class BookDetails {
    public String bookName;
    public String author;
    public int bookNum;
    public int bookPrice;

    public BookDetails(){}

    public BookDetails(String bookName, String author,int bookNum,int bookPrice){
        this.bookName = bookName;
        this.author = author;
        this.bookNum = bookNum;
        this.bookPrice = bookPrice;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getBookName() {
        return bookName;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getAuthor() {
        return author;
    }

    public void setBookNum(int bookNum) {
        this.bookNum = bookNum;
    }

    public int getBookNum() {
        return bookNum;
    }

    public void setBookPrice(int bookPrice) {
        this.bookPrice = bookPrice;
    }

    public int getBookPrice() {
        return bookPrice;
    }


    public String toString() {
        return "\n BookDetails: " +
                "\n Book Name: " + bookName +
                "\n Author: " + author +
                "\n Book No: " + bookNum +
                "\n Book Price: $" + bookPrice;
    }

    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        BookDetails book;
        BookDetails[] shelf = new BookDetails[2];

        /*System.out.println("Input book name: ");
        book.setBookName(scan.next());
        System.out.println("Input book author: ");
        book.setAuthor(scan.next());
        System.out.println("Input book ID: ");
        book.setBookNum(scan.nextInt());
        System.out.println("Input book Price: ");
        book.setBookPrice(scan.nextInt());

        for(int i=0; i< shelf.length; i++){
            if(shelf[i] == null){
                shelf[i] = book;
                break;
            }
        }*/

        for(int i=0; i< shelf.length; i++){
            book = new BookDetails();
            System.out.println("Input book name: ");
            book.setBookName(scan.next());
            System.out.println("Input book author: ");
            book.setAuthor(scan.next());
            System.out.println("Input book ID: ");
            book.setBookNum(scan.nextInt());
            System.out.println("Input book Price: ");
            book.setBookPrice(scan.nextInt());
            shelf[i] = book;
            }

        int count = 0;
        for(BookDetails b : shelf){
            if(b != null){
                System.out.println(b.toString());
                System.out.println("[" + count + "]"+ "[" + b.getBookNum() + "] " + "Title: " + b.getBookName() + " By: " + b.getAuthor());}
                count++;
        }


    }
}
