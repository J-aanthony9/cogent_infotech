public class NumQuestion {
    public static void main(String[] args){

        if (args.length == 0){
            System.out.println("There are no args ma boy");
        }
        else{
            int ar1 = Integer.valueOf(args[0]);
            int ar2 = Integer.valueOf(args[1]);

            System.out.println("Nums: " + ar1 + " " + ar2);


            int sum = ar1 + ar2;
            int num2 =ar2;
            int temp = 0;

            System.out.print(ar1 + "," + ar2 + ",");

            for (int i=0; i < 11; i++){

                System.out.print(sum + ",");

                temp = sum;
                sum = num2 + temp;
                num2 = temp;
            }
            System.out.println(sum);

        }
    }
}
