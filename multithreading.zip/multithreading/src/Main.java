class MyThread extends Thread{
    MyThread(){
        super("Demo Thread");
        System.out.println("The child thread:" + this);
        start();
    }
    @Override
    public void run(){
        for(int i=5;i>0;i--){
            System.out.println("Child thread:" + i);
        }
        System.out.println("Exiting the child thread!!!");
    }
}

/*class MyThread implements Runnable{
    @Override
    public void run(){
        for(int i = 0; i<=10;i++){
            System.out.println("i:" + i + "\t");
        }
    }
}*/


/*public class Main {
    public static void main(String[] args) {
        MyThread mt = new MyThread();
        Thread th = new Thread(mt);
        th.start();

        for(int j = 0; j<=10;j++){
            System.out.println("j:" + j + "\t");
        }
    }
}*/

public class Main {
    public static void main(String[] args) {
        new MyThread3();
        for(int i=5;i>0;i--){
            System.out.println("Main thread" + i);
        }
        System.out.println("Exiting the main thread!!");
    }
}
