class MyThread2 extends Thread{

    MyThread2(){
        super("New thread guy");
        System.out.println("Thread" + this);
        start();
    }

    @Override
    public void run(){
        for(int i=4; i > 0; i--){
            System.out.println("Child Thread" + i);
        }
        System.out.println("Threading children complete");
    }
}

public class Main2 {
    public static void main(String[] args) {
       new MyThread2();
        for(int j=4; j > 0; j--){
            System.out.println("Main Thread" + j);
        }
        System.out.println("Threading Main complete");
    }
    }

