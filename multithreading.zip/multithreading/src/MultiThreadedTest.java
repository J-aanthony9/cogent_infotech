public class MultiThreadedTest extends Thread{
    public static void main(String[] args) {
        MultiThreadedTest mt = new MultiThreadedTest();
        mt.setPriority(MAX_PRIORITY);
        mt.setName("Jay");
        mt.start();

        MultiThreadedTest mt1 = new MultiThreadedTest();
        mt1.setPriority(MIN_PRIORITY);
        mt1.setName("Jones");
        mt1.start();

    }

    @Override
    public void run(){
        System.out.println("Thread Name:" + Thread.currentThread().getName());
    }
}
