public class MyThread3 implements Runnable{

    MyThread3(){
        super();
        System.out.println("Thread:" + this);
        run();
    }

    @Override
    public void run(){
        System.out.println("Thread is running " + this);


    }

    public static void main(String[] args) {
        MyThread3 r = new MyThread3();
        MyThread3 t = new MyThread3();
        MyThread3 s = new MyThread3();
    }
}

