public class ThreadDemo extends Thread{
    public static void main(String[] args) {
        ThreadDemo t = new ThreadDemo();
        ThreadDemo r = new ThreadDemo();

        t.start();
        r.start();


    }
    @Override
    public void run(){
        System.out.println("We running");
    }

}
